class SecureStorage {
  Future<void> write(String k, String v) async {}
  Future<String?> read(String k) async => null;
}
