import 'package:flutter/material.dart';
import '../../../../core/widgets/app_scaffold.dart';
class ActivityPage extends StatelessWidget {
  const ActivityPage({super.key});
  @override
  Widget build(BuildContext context) => const AppScaffold(
    title: 'ActivityPage',
    child: Center(child: Text('Coming soon: Implement activity feature UI')),
  );
}
