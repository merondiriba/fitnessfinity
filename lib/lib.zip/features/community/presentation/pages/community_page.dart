import 'package:flutter/material.dart';
import '../../../../core/widgets/app_scaffold.dart';
class CommunityPage extends StatelessWidget {
  const CommunityPage({super.key});
  @override
  Widget build(BuildContext context) => const AppScaffold(
    title: 'CommunityPage',
    child: Center(child: Text('Coming soon: Implement community feature UI')),
  );
}
