import 'package:flutter/material.dart';
import '../../../../core/widgets/app_scaffold.dart';
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => const AppScaffold(
    title: 'ProfilePage',
    child: Center(child: Text('Coming soon: Implement profile feature UI')),
  );
}
