import 'package:flutter/material.dart';
import '../../../../core/widgets/app_scaffold.dart';
class SubscriptionsPage extends StatelessWidget {
  const SubscriptionsPage({super.key});
  @override
  Widget build(BuildContext context) => const AppScaffold(
    title: 'SubscriptionsPage',
    child: Center(child: Text('Coming soon: Implement subscriptions feature UI')),
  );
}
