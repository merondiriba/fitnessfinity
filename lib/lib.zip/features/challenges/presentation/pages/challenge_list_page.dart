import 'package:flutter/material.dart';
import '../../../../core/widgets/app_scaffold.dart';
class ChallengeListPage extends StatelessWidget {
  const ChallengeListPage({super.key});
  @override
  Widget build(BuildContext context) => const AppScaffold(
    title: 'ChallengeListPage',
    child: Center(child: Text('Coming soon: Implement challenges feature UI')),
  );
}
