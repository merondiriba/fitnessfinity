import 'package:flutter/material.dart';
import '../../../../core/widgets/app_scaffold.dart';
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) => const AppScaffold(
    title: 'SettingsPage',
    child: Center(child: Text('Coming soon: Implement settings feature UI')),
  );
}
