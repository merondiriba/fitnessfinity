import 'package:flutter/material.dart';
import '../../../../core/widgets/app_scaffold.dart';
class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});
  @override
  Widget build(BuildContext context) => const AppScaffold(
    title: 'NotificationsPage',
    child: Center(child: Text('Coming soon: Implement notifications_center feature UI')),
  );
}
