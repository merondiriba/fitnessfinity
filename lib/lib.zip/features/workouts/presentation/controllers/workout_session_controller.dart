import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

@immutable
class WorkoutSessionState {
}

class WorkoutSessionController extends StateNotifier<WorkoutSessionState> {
  WorkoutSessionController(super.state);

}

