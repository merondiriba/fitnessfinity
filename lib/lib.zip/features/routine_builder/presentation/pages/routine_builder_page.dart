import 'package:flutter/material.dart';
import '../../../../core/widgets/app_scaffold.dart';
class RoutineBuilderPage extends StatelessWidget {
  const RoutineBuilderPage({super.key});
  @override
  Widget build(BuildContext context) => const AppScaffold(
    title: 'RoutineBuilderPage',
    child: Center(child: Text('Coming soon: Implement routine_builder feature UI')),
  );
}
