import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF0BA5EC);
  static const success = Color(0xFF12B76A);
  static const warning = Color(0xFFF79009);
  static const danger  = Color(0xFFD92D20);
}
