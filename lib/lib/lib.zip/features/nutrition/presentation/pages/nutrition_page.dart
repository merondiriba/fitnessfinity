import 'package:flutter/material.dart';
import '../../../../core/widgets/app_scaffold.dart';
class NutritionPage extends StatelessWidget {
  const NutritionPage({super.key});
  @override
  Widget build(BuildContext context) => const AppScaffold(
    title: 'NutritionPage',
    child: Center(child: Text('Coming soon: Implement nutrition feature UI')),
  );
}
