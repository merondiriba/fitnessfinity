import '../repositories/home_repository.dart';
class GetHomeItems {
  final HomeRepository repo;
  GetHomeItems(this.repo);
  //Future<List<String>> call() => repo.list();
}
