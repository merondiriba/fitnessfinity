import '../repositories/onboarding_repository.dart';
class GetOnboardingItems {
  final OnboardingRepository repo;
  GetOnboardingItems(this.repo);
  //Future<List<String>> call() => repo.list();
}
