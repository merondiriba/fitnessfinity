class Env {
  static const flavor = String.fromEnvironment('FLAVOR', defaultValue: 'dev');
}
